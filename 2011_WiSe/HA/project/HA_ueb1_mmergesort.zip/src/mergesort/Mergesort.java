package mergesort;

public class Mergesort<E extends Comparable<E>> extends MMergesort<E>{
	
	public Mergesort(){
		super(1);
	}
}
